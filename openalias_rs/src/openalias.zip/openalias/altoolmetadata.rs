#[repr(C)]
pub struct AlToolMetaData_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlToolMetaData {
    pub ptr: *mut AlToolMetaData_ptr
}
