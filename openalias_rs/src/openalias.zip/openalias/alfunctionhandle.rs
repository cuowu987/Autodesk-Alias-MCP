#[repr(C)]
pub struct AlFunctionHandle_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlFunctionHandle {
    pub ptr: *mut AlFunctionHandle_ptr
}
