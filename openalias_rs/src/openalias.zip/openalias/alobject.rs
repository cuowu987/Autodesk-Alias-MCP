use crate::*;

#[repr(C)]
pub struct AlObject_ptr {
    _private: [u8; 0],
}

#[derive(Debug)]
pub struct AlObject {
    pub ptr: *mut AlObject_ptr,
}

pub trait AlObjectMethods {
    fn as_object_ptr(&self) -> *mut AlObject_ptr;

    fn is_valid(&self) -> bool {
        unsafe { alobject_is_valid(self.as_object_ptr()) }
    }

    fn are_equal(&self, other: &impl AlObjectMethods) -> bool {
        unsafe { alobject_are_equal(self.as_object_ptr(), other.as_object_ptr()) }
    }

    fn type_(&self) -> i32 {
        unsafe { alobject_type(self.as_object_ptr()) }
    }

    fn name(&self) -> Option<String> {
        let c_str = unsafe { alobject_name(self.as_object_ptr()) };
        if c_str.is_null() {
            None
        } else {
            Some(unsafe { std::ffi::CStr::from_ptr(c_str) }.to_string_lossy().to_string())
        }
    }

    fn set_name(&self, name: &str) -> Result<(), String> {
        let c_name = std::ffi::CString::new(name).map_err(|_| "Invalid string".to_string())?;
        let status = unsafe { alobject_set_name(self.as_object_ptr(), c_name.as_ptr()) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    fn delete_object(&self) -> Result<(), String> {
        let status = unsafe { alobject_delete_object(self.as_object_ptr()) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    fn destroy(&self) {
        unsafe { alobject_destroy(self.as_object_ptr()) }
    }

    fn copy_wrapper(&self) -> Option<AlObject> {
        let ptr = unsafe { alobject_copy_wrapper(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            Some(AlObject { ptr })
        }
    }

    fn as_animatable(self) -> Option<AlAnimatable>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_animatable_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAnimatable { ptr })
        }
    }

    fn as_clusterable(self) -> Option<AlClusterable>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_clusterable_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlClusterable { ptr })
        }
    }

    fn as_settable(self) -> Option<AlSettable>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_settable_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSettable { ptr })
        }
    }

    fn as_pickable(self) -> Option<AlPickable>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_pickable_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPickable { ptr })
        }
    }

    fn as_camera(self) -> Option<AlCamera>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_camera_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCamera { ptr })
        }
    }

    fn as_camera_node(self) -> Option<AlCameraNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_camera_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCameraNode { ptr })
        }
    }

    fn as_cluster(self) -> Option<AlCluster>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_cluster_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCluster { ptr })
        }
    }

    fn as_cluster_node(self) -> Option<AlClusterNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_cluster_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlClusterNode { ptr })
        }
    }

    fn as_cluster_member(self) -> Option<AlClusterMember>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_cluster_member_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlClusterMember { ptr })
        }
    }

    fn as_curve_cv(self) -> Option<AlCurveCV>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_curve_cv_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCurveCV { ptr })
        }
    }

    fn as_curve(self) -> Option<AlCurve>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_curve_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCurve { ptr })
        }
    }

    fn as_curve_node(self) -> Option<AlCurveNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_curve_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCurveNode { ptr })
        }
    }

    fn as_curve_on_surface(self) -> Option<AlCurveOnSurface>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_curve_on_surface_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCurveOnSurface { ptr })
        }
    }

    fn as_dag_node(self) -> Option<AlDagNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_dag_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlDagNode { ptr })
        }
    }

    fn as_face(self) -> Option<AlFace>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_face_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlFace { ptr })
        }
    }

    fn as_face_node(self) -> Option<AlFaceNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_face_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlFaceNode { ptr })
        }
    }

    fn as_group_node(self) -> Option<AlGroupNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_group_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlGroupNode { ptr })
        }
    }

    fn as_light(self) -> Option<AlLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlLight { ptr })
        }
    }

    fn as_light_node(self) -> Option<AlLightNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_light_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlLightNode { ptr })
        }
    }

    fn as_ambient_light(self) -> Option<AlAmbientLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_ambient_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAmbientLight { ptr })
        }
    }

    fn as_area_light(self) -> Option<AlAreaLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_area_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAreaLight { ptr })
        }
    }

    fn as_direction_light(self) -> Option<AlDirectionLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_direction_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlDirectionLight { ptr })
        }
    }

    fn as_linear_light(self) -> Option<AlLinearLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_linear_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlLinearLight { ptr })
        }
    }

    fn as_non_ambient_light(self) -> Option<AlNonAmbientLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_non_ambient_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlNonAmbientLight { ptr })
        }
    }

    fn as_point_light(self) -> Option<AlPointLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_point_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPointLight { ptr })
        }
    }

    fn as_spot_light(self) -> Option<AlSpotLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_spot_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSpotLight { ptr })
        }
    }

    fn as_volume_light(self) -> Option<AlVolumeLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_volume_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlVolumeLight { ptr })
        }
    }

    fn as_sphere_light(self) -> Option<AlSphereLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_sphere_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSphereLight { ptr })
        }
    }

    fn as_cylinder_light(self) -> Option<AlCylinderLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_cylinder_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCylinderLight { ptr })
        }
    }

    fn as_box_light(self) -> Option<AlBoxLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_box_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlBoxLight { ptr })
        }
    }

    fn as_cone_light(self) -> Option<AlConeLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_cone_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlConeLight { ptr })
        }
    }

    fn as_torus_light(self) -> Option<AlTorusLight>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_torus_light_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlTorusLight { ptr })
        }
    }

    fn as_surface_cv(self) -> Option<AlSurfaceCV>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_surface_cv_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSurfaceCV { ptr })
        }
    }

    fn as_surface(self) -> Option<AlSurface>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_surface_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSurface { ptr })
        }
    }

    fn as_surface_node(self) -> Option<AlSurfaceNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_surface_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSurfaceNode { ptr })
        }
    }

    fn as_surface_curve(self) -> Option<AlSurfaceCurve>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_surface_curve_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSurfaceCurve { ptr })
        }
    }

    fn as_set(self) -> Option<AlSet>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_set_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSet { ptr })
        }
    }

    fn as_set_member(self) -> Option<AlSetMember>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_set_member_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSetMember { ptr })
        }
    }

    fn as_shader(self) -> Option<AlShader>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_shader_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlShader { ptr })
        }
    }

    fn as_switch_shader(self) -> Option<AlSwitchShader>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_switch_shader_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSwitchShader { ptr })
        }
    }

    fn as_layered_shader(self) -> Option<AlLayeredShader>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_layered_shader_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlLayeredShader { ptr })
        }
    }

    fn as_texture(self) -> Option<AlTexture>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_texture_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlTexture { ptr })
        }
    }

    fn as_environment(self) -> Option<AlEnvironment>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_environment_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlEnvironment { ptr })
        }
    }

    fn as_keyframe(self) -> Option<AlKeyframe>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_keyframe_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlKeyframe { ptr })
        }
    }

    fn as_channel(self) -> Option<AlChannel>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_channel_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlChannel { ptr })
        }
    }

    fn as_action(self) -> Option<AlAction>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_action_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAction { ptr })
        }
    }

    fn as_param_action(self) -> Option<AlParamAction>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_param_action_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlParamAction { ptr })
        }
    }

    fn as_motion_action(self) -> Option<AlMotionAction>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_motion_action_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlMotionAction { ptr })
        }
    }

    fn as_polyset_vertex(self) -> Option<AlPolysetVertex>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_polyset_vertex_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPolysetVertex { ptr })
        }
    }

    fn as_polyset_node(self) -> Option<AlPolysetNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_polyset_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPolysetNode { ptr })
        }
    }

    fn as_polygon(self) -> Option<AlPolygon>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_polygon_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPolygon { ptr })
        }
    }

    fn as_polyset(self) -> Option<AlPolyset>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_polyset_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPolyset { ptr })
        }
    }

    fn as_mesh_node(self) -> Option<AlMeshNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_mesh_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlMeshNode { ptr })
        }
    }

    fn as_mesh(self) -> Option<AlMesh>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_mesh_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlMesh { ptr })
        }
    }

    fn as_attributes(self) -> Option<AlAttributes>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_attributes_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAttributes { ptr })
        }
    }

    fn as_arc_attributes(self) -> Option<AlArcAttributes>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_arc_attributes_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlArcAttributes { ptr })
        }
    }

    fn as_line_attributes(self) -> Option<AlLineAttributes>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_line_attributes_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlLineAttributes { ptr })
        }
    }

    fn as_curve_attributes(self) -> Option<AlCurveAttributes>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_curve_attributes_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCurveAttributes { ptr })
        }
    }

    fn as_plane_attributes(self) -> Option<AlPlaneAttributes>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_plane_attributes_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPlaneAttributes { ptr })
        }
    }

    fn as_conic_attributes(self) -> Option<AlConicAttributes>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_conic_attributes_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlConicAttributes { ptr })
        }
    }

    fn as_rev_surf_attributes(self) -> Option<AlRevSurfAttributes>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_rev_surf_attributes_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlRevSurfAttributes { ptr })
        }
    }

    fn as_joint(self) -> Option<AlJoint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_joint_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlJoint { ptr })
        }
    }

    fn as_constraint(self) -> Option<AlConstraint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_constraint_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlConstraint { ptr })
        }
    }

    fn as_point_constraint(self) -> Option<AlPointConstraint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_point_constraint_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPointConstraint { ptr })
        }
    }

    fn as_orientation_constraint(self) -> Option<AlOrientationConstraint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_orientation_constraint_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlOrientationConstraint { ptr })
        }
    }

    fn as_aim_constraint(self) -> Option<AlAimConstraint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_aim_constraint_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAimConstraint { ptr })
        }
    }

    fn as_texture_node(self) -> Option<AlTextureNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_texture_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlTextureNode { ptr })
        }
    }

    fn as_shell_node(self) -> Option<AlShellNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_shell_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlShellNode { ptr })
        }
    }

    fn as_shell(self) -> Option<AlShell>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_shell_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlShell { ptr })
        }
    }

    fn as_trim_region(self) -> Option<AlTrimRegion>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_trim_region_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlTrimRegion { ptr })
        }
    }

    fn as_trim_boundary(self) -> Option<AlTrimBoundary>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_trim_boundary_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlTrimBoundary { ptr })
        }
    }

    fn as_trim_curve(self) -> Option<AlTrimCurve>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_trim_curve_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlTrimCurve { ptr })
        }
    }

    fn as_contact(self) -> Option<AlContact>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_contact_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlContact { ptr })
        }
    }

    fn as_command_ref(self) -> Option<AlCommandRef>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_command_ref_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCommandRef { ptr })
        }
    }

    fn as_command(self) -> Option<AlCommand>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_command_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCommand { ptr })
        }
    }

    fn as_layer(self) -> Option<AlLayer>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_layer_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlLayer { ptr })
        }
    }

    fn as_orthographic_camera(self) -> Option<AlOrthographicCamera>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_orthographic_camera_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlOrthographicCamera { ptr })
        }
    }

    fn as_perspective_camera(self) -> Option<AlPerspectiveCamera>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_perspective_camera_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPerspectiveCamera { ptr })
        }
    }

    fn as_window(self) -> Option<AlWindow>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_window_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlWindow { ptr })
        }
    }

    fn as_ik_handle(self) -> Option<AlIKHandle>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_ik_handle_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlIKHandle { ptr })
        }
    }

    fn as_ik_handle_node(self) -> Option<AlIKHandleNode>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_ik_handle_node_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlIKHandleNode { ptr })
        }
    }

    fn as_locator(self) -> Option<AlLocator>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_locator_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlLocator { ptr })
        }
    }

    fn as_annotation_locator(self) -> Option<AlAnnotationLocator>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_annotation_locator_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAnnotationLocator { ptr })
        }
    }

    fn as_distance_locator(self) -> Option<AlDistanceLocator>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_distance_locator_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlDistanceLocator { ptr })
        }
    }

    fn as_angle_locator(self) -> Option<AlAngleLocator>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_angle_locator_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlAngleLocator { ptr })
        }
    }

    fn as_radial_locator(self) -> Option<AlRadialLocator>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_radial_locator_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlRadialLocator { ptr })
        }
    }

    fn as_deviation_locator(self) -> Option<AlDeviationLocator>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_deviation_locator_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlDeviationLocator { ptr })
        }
    }

    fn as_minmax_locator(self) -> Option<AlMinmaxLocator>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_minmax_locator_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlMinmaxLocator { ptr })
        }
    }

    fn as_construction_entity(self) -> Option<AlConstructionEntity>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_construction_entity_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlConstructionEntity { ptr })
        }
    }

    fn as_construction_vector(self) -> Option<AlConstructionVector>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_construction_vector_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlConstructionVector { ptr })
        }
    }

    fn as_construction_plane(self) -> Option<AlConstructionPlane>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_construction_plane_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlConstructionPlane { ptr })
        }
    }

    fn as_point(self) -> Option<AlPoint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_point_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlPoint { ptr })
        }
    }

    fn as_space_point(self) -> Option<AlSpacePoint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_space_point_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSpacePoint { ptr })
        }
    }

    fn as_curve_point(self) -> Option<AlCurvePoint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_curve_point_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCurvePoint { ptr })
        }
    }

    fn as_curve_on_surface_point(self) -> Option<AlCurveOnSurfacePoint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_curve_on_surface_point_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCurveOnSurfacePoint { ptr })
        }
    }

    fn as_surface_point(self) -> Option<AlSurfacePoint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_surface_point_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSurfacePoint { ptr })
        }
    }

    fn as_cloud(self) -> Option<AlCloud>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_cloud_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCloud { ptr })
        }
    }

    fn as_blend_curve(self) -> Option<AlBlendCurve>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_blend_curve_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlBlendCurve { ptr })
        }
    }

    fn as_blend_point(self) -> Option<AlBlendPoint>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_blend_point_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlBlendPoint { ptr })
        }
    }

    fn as_canvas(self) -> Option<AlCanvas>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_canvas_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCanvas { ptr })
        }
    }

    fn as_category(self) -> Option<AlCategory>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_category_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlCategory { ptr })
        }
    }

    fn as_subdiv(self) -> Option<AlSubdiv>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_subdiv_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlSubdiv { ptr })
        }
    }

    fn as_tool_meta_data(self) -> Option<AlToolMetaData>
    where Self: Sized  {
        let ptr = unsafe { alobject_as_tool_meta_data_ptr(self.as_object_ptr()) };
        if ptr.is_null() {
            None
        } else {
            std::mem::forget(self);
            Some(AlToolMetaData { ptr })
        }
    }
}
impl Drop for AlObject {
    fn drop(&mut self) {
        self.destroy();
    }
}

impl AlObjectMethods for AlObject {
    fn as_object_ptr(&self) -> *mut AlObject_ptr {
        self.ptr
    }
}

unsafe extern "C" {
    fn alobject_is_valid(obj: *mut AlObject_ptr) -> bool;
    fn alobject_are_equal(obj1: *mut AlObject_ptr, obj2: *mut AlObject_ptr) -> bool;
    fn alobject_type(obj: *mut AlObject_ptr) -> i32;
    fn alobject_name(obj: *mut AlObject_ptr) -> *const i8;
    fn alobject_set_name(obj: *mut AlObject_ptr, name: *const i8) -> statusCode;
    fn alobject_delete_object(obj: *mut AlObject_ptr) -> statusCode;
    fn alobject_copy_wrapper(obj: *mut AlObject_ptr) -> *mut AlObject_ptr;
    fn alobject_destroy(obj: *mut AlObject_ptr);

    fn alobject_as_animatable_ptr(obj: *mut AlObject_ptr) -> *mut AlAnimatable_ptr;
    fn alobject_as_clusterable_ptr(obj: *mut AlObject_ptr) -> *mut AlClusterable_ptr;
    fn alobject_as_settable_ptr(obj: *mut AlObject_ptr) -> *mut AlSettable_ptr;
    fn alobject_as_pickable_ptr(obj: *mut AlObject_ptr) -> *mut AlPickable_ptr;

    fn alobject_as_camera_ptr(obj: *mut AlObject_ptr) -> *mut AlCamera_ptr;
    fn alobject_as_camera_node_ptr(obj: *mut AlObject_ptr) -> *mut AlCameraNode_ptr;

    fn alobject_as_cluster_ptr(obj: *mut AlObject_ptr) -> *mut AlCluster_ptr;
    fn alobject_as_cluster_node_ptr(obj: *mut AlObject_ptr) -> *mut AlClusterNode_ptr;
    fn alobject_as_cluster_member_ptr(obj: *mut AlObject_ptr) -> *mut AlClusterMember_ptr;

    fn alobject_as_curve_cv_ptr(obj: *mut AlObject_ptr) -> *mut AlCurveCV_ptr;
    fn alobject_as_curve_ptr(obj: *mut AlObject_ptr) -> *mut AlCurve_ptr;
    fn alobject_as_curve_node_ptr(obj: *mut AlObject_ptr) -> *mut AlCurveNode_ptr;
    fn alobject_as_curve_on_surface_ptr(obj: *mut AlObject_ptr) -> *mut AlCurveOnSurface_ptr;

    fn alobject_as_dag_node_ptr(obj: *mut AlObject_ptr) -> *mut AlDagNode_ptr;

    fn alobject_as_face_ptr(obj: *mut AlObject_ptr) -> *mut AlFace_ptr;
    fn alobject_as_face_node_ptr(obj: *mut AlObject_ptr) -> *mut AlFaceNode_ptr;

    fn alobject_as_group_node_ptr(obj: *mut AlObject_ptr) -> *mut AlGroupNode_ptr;

    fn alobject_as_light_ptr(obj: *mut AlObject_ptr) -> *mut AlLight_ptr;
    fn alobject_as_light_node_ptr(obj: *mut AlObject_ptr) -> *mut AlLightNode_ptr;
    fn alobject_as_ambient_light_ptr(obj: *mut AlObject_ptr) -> *mut AlAmbientLight_ptr;
    fn alobject_as_area_light_ptr(obj: *mut AlObject_ptr) -> *mut AlAreaLight_ptr;
    fn alobject_as_direction_light_ptr(obj: *mut AlObject_ptr) -> *mut AlDirectionLight_ptr;
    fn alobject_as_linear_light_ptr(obj: *mut AlObject_ptr) -> *mut AlLinearLight_ptr;
    fn alobject_as_non_ambient_light_ptr(obj: *mut AlObject_ptr) -> *mut AlNonAmbientLight_ptr;
    fn alobject_as_point_light_ptr(obj: *mut AlObject_ptr) -> *mut AlPointLight_ptr;
    fn alobject_as_spot_light_ptr(obj: *mut AlObject_ptr) -> *mut AlSpotLight_ptr;
    fn alobject_as_volume_light_ptr(obj: *mut AlObject_ptr) -> *mut AlVolumeLight_ptr;
    fn alobject_as_sphere_light_ptr(obj: *mut AlObject_ptr) -> *mut AlSphereLight_ptr;
    fn alobject_as_cylinder_light_ptr(obj: *mut AlObject_ptr) -> *mut AlCylinderLight_ptr;
    fn alobject_as_box_light_ptr(obj: *mut AlObject_ptr) -> *mut AlBoxLight_ptr;
    fn alobject_as_cone_light_ptr(obj: *mut AlObject_ptr) -> *mut AlConeLight_ptr;
    fn alobject_as_torus_light_ptr(obj: *mut AlObject_ptr) -> *mut AlTorusLight_ptr;

    fn alobject_as_surface_cv_ptr(obj: *mut AlObject_ptr) -> *mut AlSurfaceCV_ptr;
    fn alobject_as_surface_ptr(obj: *mut AlObject_ptr) -> *mut AlSurface_ptr;
    fn alobject_as_surface_node_ptr(obj: *mut AlObject_ptr) -> *mut AlSurfaceNode_ptr;
    fn alobject_as_surface_curve_ptr(obj: *mut AlObject_ptr) -> *mut AlSurfaceCurve_ptr;

    fn alobject_as_set_ptr(obj: *mut AlObject_ptr) -> *mut AlSet_ptr;
    fn alobject_as_set_member_ptr(obj: *mut AlObject_ptr) -> *mut AlSetMember_ptr;

    fn alobject_as_shader_ptr(obj: *mut AlObject_ptr) -> *mut AlShader_ptr;
    fn alobject_as_switch_shader_ptr(obj: *mut AlObject_ptr) -> *mut AlSwitchShader_ptr;
    fn alobject_as_layered_shader_ptr(obj: *mut AlObject_ptr) -> *mut AlLayeredShader_ptr;
    fn alobject_as_texture_ptr(obj: *mut AlObject_ptr) -> *mut AlTexture_ptr;
    fn alobject_as_environment_ptr(obj: *mut AlObject_ptr) -> *mut AlEnvironment_ptr;

    fn alobject_as_keyframe_ptr(obj: *mut AlObject_ptr) -> *mut AlKeyframe_ptr;
    fn alobject_as_channel_ptr(obj: *mut AlObject_ptr) -> *mut AlChannel_ptr;
    fn alobject_as_action_ptr(obj: *mut AlObject_ptr) -> *mut AlAction_ptr;
    fn alobject_as_param_action_ptr(obj: *mut AlObject_ptr) -> *mut AlParamAction_ptr;
    fn alobject_as_motion_action_ptr(obj: *mut AlObject_ptr) -> *mut AlMotionAction_ptr;

    fn alobject_as_polyset_vertex_ptr(obj: *mut AlObject_ptr) -> *mut AlPolysetVertex_ptr;
    fn alobject_as_polyset_node_ptr(obj: *mut AlObject_ptr) -> *mut AlPolysetNode_ptr;
    fn alobject_as_polygon_ptr(obj: *mut AlObject_ptr) -> *mut AlPolygon_ptr;
    fn alobject_as_polyset_ptr(obj: *mut AlObject_ptr) -> *mut AlPolyset_ptr;

    fn alobject_as_mesh_node_ptr(obj: *mut AlObject_ptr) -> *mut AlMeshNode_ptr;
    fn alobject_as_mesh_ptr(obj: *mut AlObject_ptr) -> *mut AlMesh_ptr;

    fn alobject_as_attributes_ptr(obj: *mut AlObject_ptr) -> *mut AlAttributes_ptr;
    fn alobject_as_arc_attributes_ptr(obj: *mut AlObject_ptr) -> *mut AlArcAttributes_ptr;
    fn alobject_as_line_attributes_ptr(obj: *mut AlObject_ptr) -> *mut AlLineAttributes_ptr;
    fn alobject_as_curve_attributes_ptr(obj: *mut AlObject_ptr) -> *mut AlCurveAttributes_ptr;
    fn alobject_as_plane_attributes_ptr(obj: *mut AlObject_ptr) -> *mut AlPlaneAttributes_ptr;
    fn alobject_as_conic_attributes_ptr(obj: *mut AlObject_ptr) -> *mut AlConicAttributes_ptr;
    fn alobject_as_rev_surf_attributes_ptr(obj: *mut AlObject_ptr) -> *mut AlRevSurfAttributes_ptr;

    fn alobject_as_joint_ptr(obj: *mut AlObject_ptr) -> *mut AlJoint_ptr;
    fn alobject_as_constraint_ptr(obj: *mut AlObject_ptr) -> *mut AlConstraint_ptr;
    fn alobject_as_point_constraint_ptr(obj: *mut AlObject_ptr) -> *mut AlPointConstraint_ptr;
    fn alobject_as_orientation_constraint_ptr(obj: *mut AlObject_ptr) -> *mut AlOrientationConstraint_ptr;
    fn alobject_as_aim_constraint_ptr(obj: *mut AlObject_ptr) -> *mut AlAimConstraint_ptr;

    fn alobject_as_texture_node_ptr(obj: *mut AlObject_ptr) -> *mut AlTextureNode_ptr;

    fn alobject_as_shell_node_ptr(obj: *mut AlObject_ptr) -> *mut AlShellNode_ptr;
    fn alobject_as_shell_ptr(obj: *mut AlObject_ptr) -> *mut AlShell_ptr;

    fn alobject_as_trim_region_ptr(obj: *mut AlObject_ptr) -> *mut AlTrimRegion_ptr;
    fn alobject_as_trim_boundary_ptr(obj: *mut AlObject_ptr) -> *mut AlTrimBoundary_ptr;
    fn alobject_as_trim_curve_ptr(obj: *mut AlObject_ptr) -> *mut AlTrimCurve_ptr;

    fn alobject_as_contact_ptr(obj: *mut AlObject_ptr) -> *mut AlContact_ptr;
    fn alobject_as_command_ref_ptr(obj: *mut AlObject_ptr) -> *mut AlCommandRef_ptr;
    fn alobject_as_command_ptr(obj: *mut AlObject_ptr) -> *mut AlCommand_ptr;
    fn alobject_as_layer_ptr(obj: *mut AlObject_ptr) -> *mut AlLayer_ptr;

    fn alobject_as_orthographic_camera_ptr(obj: *mut AlObject_ptr) -> *mut AlOrthographicCamera_ptr;
    fn alobject_as_perspective_camera_ptr(obj: *mut AlObject_ptr) -> *mut AlPerspectiveCamera_ptr;
    fn alobject_as_window_ptr(obj: *mut AlObject_ptr) -> *mut AlWindow_ptr;

    fn alobject_as_ik_handle_ptr(obj: *mut AlObject_ptr) -> *mut AlIKHandle_ptr;
    fn alobject_as_ik_handle_node_ptr(obj: *mut AlObject_ptr) -> *mut AlIKHandleNode_ptr;

    fn alobject_as_locator_ptr(obj: *mut AlObject_ptr) -> *mut AlLocator_ptr;
    fn alobject_as_annotation_locator_ptr(obj: *mut AlObject_ptr) -> *mut AlAnnotationLocator_ptr;
    fn alobject_as_distance_locator_ptr(obj: *mut AlObject_ptr) -> *mut AlDistanceLocator_ptr;
    fn alobject_as_angle_locator_ptr(obj: *mut AlObject_ptr) -> *mut AlAngleLocator_ptr;
    fn alobject_as_radial_locator_ptr(obj: *mut AlObject_ptr) -> *mut AlRadialLocator_ptr;
    fn alobject_as_deviation_locator_ptr(obj: *mut AlObject_ptr) -> *mut AlDeviationLocator_ptr;
    fn alobject_as_minmax_locator_ptr(obj: *mut AlObject_ptr) -> *mut AlMinmaxLocator_ptr;

    fn alobject_as_construction_entity_ptr(obj: *mut AlObject_ptr) -> *mut AlConstructionEntity_ptr;
    fn alobject_as_construction_vector_ptr(obj: *mut AlObject_ptr) -> *mut AlConstructionVector_ptr;
    fn alobject_as_construction_plane_ptr(obj: *mut AlObject_ptr) -> *mut AlConstructionPlane_ptr;
    fn alobject_as_point_ptr(obj: *mut AlObject_ptr) -> *mut AlPoint_ptr;
    fn alobject_as_space_point_ptr(obj: *mut AlObject_ptr) -> *mut AlSpacePoint_ptr;
    fn alobject_as_curve_point_ptr(obj: *mut AlObject_ptr) -> *mut AlCurvePoint_ptr;
    fn alobject_as_curve_on_surface_point_ptr(obj: *mut AlObject_ptr) -> *mut AlCurveOnSurfacePoint_ptr;
    fn alobject_as_surface_point_ptr(obj: *mut AlObject_ptr) -> *mut AlSurfacePoint_ptr;

    fn alobject_as_cloud_ptr(obj: *mut AlObject_ptr) -> *mut AlCloud_ptr;

    fn alobject_as_blend_curve_ptr(obj: *mut AlObject_ptr) -> *mut AlBlendCurve_ptr;
    fn alobject_as_blend_point_ptr(obj: *mut AlObject_ptr) -> *mut AlBlendPoint_ptr;
    fn alobject_as_canvas_ptr(obj: *mut AlObject_ptr) -> *mut AlCanvas_ptr;
    fn alobject_as_category_ptr(obj: *mut AlObject_ptr) -> *mut AlCategory_ptr;

    fn alobject_as_subdiv_ptr(obj: *mut AlObject_ptr) -> *mut AlSubdiv_ptr;
    fn alobject_as_tool_meta_data_ptr(obj: *mut AlObject_ptr) -> *mut AlToolMetaData_ptr;
}
