#[repr(C)]
pub struct AlCurveNode_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlCurveNode {
    pub ptr: *mut AlCurveNode_ptr
}
