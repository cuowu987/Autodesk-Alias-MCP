#[repr(C)]
pub struct AlGroupNode_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlGroupNode {
    pub ptr: *mut AlGroupNode_ptr
}
