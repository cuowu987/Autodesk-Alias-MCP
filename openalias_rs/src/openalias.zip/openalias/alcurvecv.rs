#[repr(C)]
pub struct AlCurveCV_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlCurveCV {
    pub ptr: *mut AlCurveCV_ptr
}
