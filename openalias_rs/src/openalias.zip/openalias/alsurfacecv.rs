#[repr(C)]
pub struct AlSurfaceCV_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlSurfaceCV {
    pub ptr: *mut AlSurfaceCV_ptr
}
