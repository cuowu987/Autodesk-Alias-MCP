#[repr(C)]
pub struct AlConstructionVector_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlConstructionVector {
    pub ptr: *mut AlConstructionVector_ptr
}
