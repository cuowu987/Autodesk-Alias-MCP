use super::*;

#[repr(C)]
pub struct AlWindow_ptr {
    _private: [u8; 0],
}

#[derive(Debug)]
pub struct AlWindow {
    pub ptr: *mut AlWindow_ptr,
}

impl AlWindow {
    pub fn new() -> AlWindow {
        let ptr = unsafe { alwindow_create() };
        if ptr.is_null() {
            AlWindow { ptr: std::ptr::null_mut() }
        } else {
            AlWindow { ptr }
        }
    }


    pub fn destroy(&mut self) {
        unsafe { alwindow_destroy(self.ptr) };
    }

    pub fn create_window(&self, view_type: AlWindowViewType) -> Result<(), String> {
        let status = unsafe { alwindow_create_window(self.ptr, view_type) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn next(&self) -> Option<AlWindow> {
        let ptr = unsafe { alwindow_next(self.ptr) };
        if ptr.is_null() {
            None
        } else {
            Some(AlWindow { ptr })
        }
    }

    pub fn prev(&self) -> Option<AlWindow> {
        let ptr = unsafe { alwindow_prev(self.ptr) };
        if ptr.is_null() {
            None
        } else {
            Some(AlWindow { ptr })
        }
    }

    pub fn next_d(&self) -> Result<(), String> {
        let status = unsafe { alwindow_next_d(self.ptr) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn prev_d(&self) -> Result<(), String> {
        let status = unsafe { alwindow_prev_d(self.ptr) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn window_type(&self) -> Result<AlWindowViewType, String> {
        let mut view_type = AlWindowViewType::Perspective;
        let status = unsafe { alwindow_window_type(self.ptr, &mut view_type) };
        if status == statusCode::Success {
            Ok(view_type)
        } else {
            Err(status.to_string())
        }
    }

    pub fn is_zoom(&self) -> Result<bool, String> {
        let mut is_zoom = false;
        let status = unsafe { alwindow_is_zoom(self.ptr, &mut is_zoom) };
        if status == statusCode::Success {
            Ok(is_zoom)
        } else {
            Err(status.to_string())
        }
    }

    pub fn is_visible(&self) -> Result<bool, String> {
        let mut is_visible = false;
        let status = unsafe { alwindow_is_visible(self.ptr, &mut is_visible) };
        if status == statusCode::Success {
            Ok(is_visible)
        } else {
            Err(status.to_string())
        }
    }

    pub fn orthographic(&self) -> Result<bool, String> {
        let mut orthographic = false;
        let status = unsafe { alwindow_orthographic(self.ptr, &mut orthographic) };
        if status == statusCode::Success {
            Ok(orthographic)
        } else {
            Err(status.to_string())
        }
    }

    pub fn camera(&self) -> Option<AlCamera> {
        let ptr = unsafe { alwindow_camera(self.ptr) };
        if ptr.is_null() {
            None
        } else {
            Some(AlCamera { ptr })
        }
    }

    pub fn set_camera(&self, camera: &AlPerspectiveCamera) -> Result<(), String> {
        let status = unsafe { alwindow_set_camera(self.ptr, camera.ptr) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn position(&self) -> Result<(i32, i32), String> {
        let mut x: i32 = 0;
        let mut y: i32 = 0;
        let status = unsafe { alwindow_position(self.ptr, &mut x, &mut y) };
        if status == statusCode::Success {
            Ok((x, y))
        } else {
            Err(status.to_string())
        }
    }

    pub fn set_position(&self, x: i32, y: i32) -> Result<(), String> {
        let status = unsafe { alwindow_set_position(self.ptr, x, y) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn resolution(&self) -> Result<(i32, i32), String> {
        let mut width: i32 = 0;
        let mut height: i32 = 0;
        let status = unsafe { alwindow_resolution(self.ptr, &mut width, &mut height) };
        if status == statusCode::Success {
            Ok((width, height))
        } else {
            Err(status.to_string())
        }
    }

    pub fn set_resolution(&self, width: i32, height: i32, corner: AlWindowCornerType, aspect: AlWindowAspectType) -> Result<(), String> {
        let status = unsafe { alwindow_set_resolution(self.ptr, width, height, corner, aspect) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn priority(&self) -> Result<i32, String> {
        let mut priority = 0;
        let status = unsafe { alwindow_priority(self.ptr, &mut priority) };
        if status == statusCode::Success {
            Ok(priority)
        } else {
            Err(status.to_string())
        }
    }

    pub fn set_priority(&self, priority: i32) -> Result<(), String> {
        let status = unsafe { alwindow_set_priority(self.ptr, priority) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn grid_size(&self) -> f64 {
        unsafe { alwindow_grid_size(self.ptr) }
    }

    pub fn set_grid_size(&self, size: f64) -> Result<(), String> {
        let status = unsafe { alwindow_set_grid_size(self.ptr, size) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn world_space_bounds(&self) -> Result<([f64; 3], [f64; 3]), String> {
        let mut min_x: f64 = 0.0;
        let mut min_y: f64 = 0.0;
        let mut min_z: f64 = 0.0;
        let mut max_x: f64 = 0.0;
        let mut max_y: f64 = 0.0;
        let mut max_z: f64 = 0.0;
        let status = unsafe {
            alwindow_world_space_bounds(self.ptr, &mut min_x, &mut min_y, &mut min_z, &mut max_x, &mut max_y, &mut max_z)
        };
        if status == statusCode::Success {
            Ok(([min_x, min_y, min_z], [max_x, max_y, max_z]))
        } else {
            Err(status.to_string())
        }
    }

    pub fn map_to_world_space(&self, screen_x: i32, screen_y: i32) -> Result<([f64; 3], [f64; 3]), String> {
        let mut world_x: f64 = 0.0;
        let mut world_y: f64 = 0.0;
        let mut world_z: f64 = 0.0;
        let mut normal_x: f64 = 0.0;
        let mut normal_y: f64 = 0.0;
        let mut normal_z: f64 = 0.0;
        let status = unsafe {
            alwindow_map_to_world_space(self.ptr, screen_x, screen_y, &mut world_x, &mut world_y, &mut world_z, &mut normal_x, &mut normal_y, &mut normal_z)
        };
        if status == statusCode::Success {
            Ok(([world_x, world_y, world_z], [normal_x, normal_y, normal_z]))
        } else {
            Err(status.to_string())
        }
    }

    pub fn window_toggle(&self, item: AlWindowToggle) -> Result<bool, String> {
        let mut state = false;
        let status = unsafe { alwindow_window_toggle(self.ptr, item, &mut state) };
        if status == statusCode::Success {
            Ok(state)
        } else {
            Err(status.to_string())
        }
    }

    pub fn set_window_toggle(&self, item: AlWindowToggle, state: bool) -> Result<(), String> {
        let status = unsafe { alwindow_set_window_toggle(self.ptr, item, state) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }

    pub fn alias_window_size() -> Result<(i32, i32), String> {
        let mut width: i32 = 0;
        let mut height: i32 = 0;
        let status = unsafe { alwindow_alias_window_size(&mut width, &mut height) };
        if status == statusCode::Success {
            Ok((width, height))
        } else {
            Err(status.to_string())
        }
    }

    pub fn alias_window_position() -> Result<(i32, i32), String> {
        let mut x: i32 = 0;
        let mut y: i32 = 0;
        let status = unsafe { alwindow_alias_window_position(&mut x, &mut y) };
        if status == statusCode::Success {
            Ok((x, y))
        } else {
            Err(status.to_string())
        }
    }

    pub fn create_default_windows() {
        unsafe { alwindow_create_default_windows() };
    }
}

#[repr(i32)]
#[derive(Debug, Clone, Copy)]
pub enum AlWindowViewType {
    Perspective = 0,
    Orthographic = 1,
}

#[repr(i32)]
#[derive(Debug, Clone, Copy)]
pub enum AlWindowCornerType {
    TopLeft = 0,
    TopRight = 1,
    BottomLeft = 2,
    BottomRight = 3,
}

#[repr(i32)]
#[derive(Debug, Clone, Copy)]
pub enum AlWindowAspectType {
    KeepAspectRatio = 0,
    IgnoreAspectRatio = 1,
}

#[repr(i32)]
#[derive(Debug, Clone, Copy)]
pub enum AlWindowToggle {
    Unknown = -1,
    None = 0,
    Front = 1,
    Side = 2,
    Top = 3,
    Uv = 4,
    Shading = 5,
    Texture = 6,
    Material = 7,
    Lighting = 8,
    WorldAxis = 9,
    Grid = 10,
    Frame = 11,
    HeadsUpDisplay = 12,
    DefaultLights = 13,
    CustomLights = 14,
    NoLights = 15,
    Background = 16,
    Profile = 17,
    Smooth = 18,
    HardEdit = 19,
    Xray = 20,
    Maximize = 21,
    Curve = 22,
    KeepRange = 23,
    NoUpdate = 24,
    NoDraw = 25,
    Fade = 26,
    Label = 27,
    User1 = 28,
    User2 = 29,
    User3 = 30,
}

unsafe extern "C" {
    fn alwindow_create() -> *mut AlWindow_ptr;
    fn alwindow_destroy(window: *mut AlWindow_ptr);
    fn alwindow_create_window(window: *mut AlWindow_ptr, viewType: AlWindowViewType) -> statusCode;
    fn alwindow_next(window: *mut AlWindow_ptr) -> *mut AlWindow_ptr;
    fn alwindow_prev(window: *mut AlWindow_ptr) -> *mut AlWindow_ptr;
    fn alwindow_next_d(window: *mut AlWindow_ptr) -> statusCode;
    fn alwindow_prev_d(window: *mut AlWindow_ptr) -> statusCode;
    fn alwindow_window_type(window: *mut AlWindow_ptr, outViewType: &mut AlWindowViewType) -> statusCode;
    fn alwindow_is_zoom(window: *mut AlWindow_ptr, outIsZoom: &mut bool) -> statusCode;
    fn alwindow_is_visible(window: *mut AlWindow_ptr, outIsVisible: &mut bool) -> statusCode;
    fn alwindow_orthographic(window: *mut AlWindow_ptr, outOrthographic: &mut bool) -> statusCode;
    fn alwindow_camera(window: *mut AlWindow_ptr) -> *mut crate::openalias::AlCamera_ptr;
    fn alwindow_set_camera(window: *mut AlWindow_ptr, camera: *mut crate::openalias::AlPerspectiveCamera_ptr) -> statusCode;
    fn alwindow_position(window: *mut AlWindow_ptr, outX: &mut i32, outY: &mut i32) -> statusCode;
    fn alwindow_set_position(window: *mut AlWindow_ptr, x: i32, y: i32) -> statusCode;
    fn alwindow_resolution(window: *mut AlWindow_ptr, outWidth: &mut i32, outHeight: &mut i32) -> statusCode;
    fn alwindow_set_resolution(window: *mut AlWindow_ptr, width: i32, height: i32, corner: AlWindowCornerType, aspect: AlWindowAspectType) -> statusCode;
    fn alwindow_priority(window: *mut AlWindow_ptr, outPriority: &mut i32) -> statusCode;
    fn alwindow_set_priority(window: *mut AlWindow_ptr, priority: i32) -> statusCode;
    fn alwindow_grid_size(window: *mut AlWindow_ptr) -> f64;
    fn alwindow_set_grid_size(window: *mut AlWindow_ptr, size: f64) -> statusCode;
    fn alwindow_world_space_bounds(window: *mut AlWindow_ptr, outMinX: &mut f64, outMinY: &mut f64, outMinZ: &mut f64, outMaxX: &mut f64, outMaxY: &mut f64, outMaxZ: &mut f64) -> statusCode;
    fn alwindow_map_to_world_space(window: *mut AlWindow_ptr, screenX: i32, screenY: i32, outWorldX: &mut f64, outWorldY: &mut f64, outWorldZ: &mut f64, outNormalX: &mut f64, outNormalY: &mut f64, outNormalZ: &mut f64) -> statusCode;
    fn alwindow_window_toggle(window: *mut AlWindow_ptr, item: AlWindowToggle, outState: &mut bool) -> statusCode;
    fn alwindow_set_window_toggle(window: *mut AlWindow_ptr, item: AlWindowToggle, state: bool) -> statusCode;
    fn alwindow_alias_window_size(outWidth: &mut i32, outHeight: &mut i32) -> statusCode;
    fn alwindow_alias_window_position(outX: &mut i32, outY: &mut i32) -> statusCode;
    fn alwindow_create_default_windows();
}

impl Drop for AlWindow {
    fn drop(&mut self) {
        self.destroy();
        self.ptr = std::ptr::null_mut();
    }
}

impl AlObjectMethods for AlWindow {
    fn as_object_ptr(&self) -> *mut AlObject_ptr {
        self.ptr as *mut AlObject_ptr
    }
}
