#[repr(C)]
pub struct AlOrthographicCamera_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlOrthographicCamera {
    pub ptr: *mut AlOrthographicCamera_ptr
}
