mod alfunction;
mod alcontinuousfunction;
mod almomentaryfunction;
pub use alfunction::*;
pub use alcontinuousfunction::*;
pub use almomentaryfunction::*;