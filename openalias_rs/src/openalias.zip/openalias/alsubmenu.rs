#[repr(C)]
pub struct AlSubmenu_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlSubmenu {
    pub ptr: *mut AlSubmenu_ptr
}
