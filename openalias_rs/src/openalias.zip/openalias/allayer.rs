#[repr(C)]
pub struct AlLayer_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlLayer {
    pub ptr: *mut AlLayer_ptr
}
