use crate::*;
use alias_libs::{Point_Trait};

#[repr(C)]
pub struct AlSpacePoint_ptr {
    _private: [u8; 0],
}

#[repr(C)]
#[derive(Debug)]
pub struct AlSpacePoint {
    pub ptr: *mut AlSpacePoint_ptr,
}

impl Drop for AlSpacePoint {
    fn drop(&mut self) {
        self.destroy();
        self.ptr = std::ptr::null_mut();
    }
}

impl Point_Trait for AlSpacePoint {
    fn X(&self) -> f64 {
        let s = self.world_position().unwrap();
        s.0
    }
    fn Y(&self) -> f64 {
        let s = self.world_position().unwrap();
        s.1
    }
    fn Z(&self) -> f64 {
        let s = self.world_position().unwrap();
        s.2
    }
    fn W(&self) -> f64 {
        1.0
    }
    fn SetX(&mut self, x: f64) {
        let s = self.world_position().unwrap();
        self.set_world_position(x, s.1, s.2).unwrap();
    }
    fn SetY(&mut self, y: f64) {
        let s = self.world_position().unwrap();
        self.set_world_position(s.0, y, s.2).unwrap();
    }
    fn SetZ(&mut self, z: f64) {
        let s = self.world_position().unwrap();
        self.set_world_position(s.0, s.1, z).unwrap();
    }
    fn SetW(&mut self, _w: f64) {
        //do nothing
    }
}

impl AlSpacePoint {
    pub fn create(x: f64, y: f64, z: f64) -> Result<AlSpacePoint, String> {
        let mut ptr = std::ptr::null_mut();
        unsafe { alsacepoint_new(&mut ptr) };
        let status = unsafe { alsacepoint_create(ptr, x, y, z) };
        if status == statusCode::Success {
            Ok(AlSpacePoint { ptr })
        } else {
            Err(status.to_string())
        }
    }

    pub fn set_world_position(&self, x: f64, y: f64, z: f64) -> Result<(), String> {
        let status = unsafe { alsacepoint_set_world_position(self.ptr, x, y, z) };
        if status == statusCode::Success {
            Ok(())
        } else {
            Err(status.to_string())
        }
    }
}

impl AlObjectMethods for AlSpacePoint {
    fn as_object_ptr(&self) -> *mut AlObject_ptr {
        self.ptr as *mut AlObject_ptr
    }
}

impl AlPointMethods for AlSpacePoint {
    fn as_point_ptr(&self) -> *mut AlPoint_ptr {
        self.ptr as *mut AlPoint_ptr
    }
}

unsafe extern "C" {
    fn alsacepoint_new(spacePoint: *mut *mut AlSpacePoint_ptr) -> statusCode;
    fn alsacepoint_create(spacePoint: *mut AlSpacePoint_ptr, x: f64, y: f64, z: f64) -> statusCode;
    fn alsacepoint_set_world_position(
        spacePoint: *mut AlSpacePoint_ptr,
        x: f64,
        y: f64,
        z: f64,
    ) -> statusCode;
}
