#[repr(C)]
pub struct AlCurveOnSurface_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlCurveOnSurface {
    pub ptr: *mut AlCurveOnSurface_ptr
}
