#[repr(C)]
pub struct AlMainMenu_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlMainMenu {
    pub ptr: *mut AlMainMenu_ptr
}
