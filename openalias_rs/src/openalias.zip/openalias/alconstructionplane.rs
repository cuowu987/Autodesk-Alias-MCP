#[repr(C)]
pub struct AlConstructionPlane_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlConstructionPlane {
    pub ptr: *mut AlConstructionPlane_ptr
}
