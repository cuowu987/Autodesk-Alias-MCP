#[repr(C)]
pub struct AlCurve_ptr {
    _private: [u8; 0], // 不透明
}

#[derive(Debug)]
pub struct AlCurve {
    pub ptr: *mut AlCurve_ptr
}
